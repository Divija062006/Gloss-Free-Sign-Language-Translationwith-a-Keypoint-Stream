# Files to copy here from Kaggle

Open the notebook **03_train_part2_with_keypoints** on Kaggle → **Output** → folder **runs**, and download:

- `results_all.json` (all four models, all metrics, training histories)
- `results_table.csv`
- `curves.png` and `vlp_curves.png` (training curves)
- `*_test_translations.tsv` (every test sentence: reference and model output)

From **03_train_part1_no_keypoints** → Output → runs, also download `E1_rgb_s0_test_translations.tsv` and `E3_rgb_vlp_s0_test_translations.tsv`.

Do **not** upload `.pth` (model checkpoints) or `.pkl` (features/keypoints): GitHub rejects files over 100 MB, and the scripts regenerate them.

Delete this file once the results are in.
